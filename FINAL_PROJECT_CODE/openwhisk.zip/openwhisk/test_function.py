# from datetime import datetime
# import random

# startNumber = 1
# endNumber = 10000
# prime = []
# for i in range(startNumber,endNumber):
#     for p in range(2, i):
#         if (i % p)==0:
#             break
#     else:
#         prime.append(i)
# num = random.sample(prime, 1)
# now = datetime.now()
# message = str("The random prime number this "+now.strftime("%A")+" at "+now.strftime("%R")+" is: "+str(num[0]))
# print(message)


import time
import json

def main():
    # Simulate some computational work
    result = 0
    for i in range(1000):
        result += i * i
    
    # Simulate I/O delay
    time.sleep(0.01)
    
    response = {
        "status": "success",
        "result": result,
        "message": "Function executed successfully"
    }
    
    print(json.dumps(response))
    return response

if __name__ == "__main__":
    main()